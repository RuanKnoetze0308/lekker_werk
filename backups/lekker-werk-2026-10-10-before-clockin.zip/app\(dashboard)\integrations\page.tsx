import Link from "next/link";
import { Badge, Card, EmptyState, PageHeader, StatCard, Table, Td, Th, statusTone } from "@/components/dashboard/ui";
import { catalogByProvider } from "@/lib/integration-catalog";
import { addDays, formatDateTime, localDate } from "@/lib/time";
import { requirePageContext } from "@/server/auth/guards";
import { getCompany } from "@/server/services/company.service";
import { importedHoursSummary, listIntegrations, listSyncs } from "@/server/services/integration.service";
import { IntegrationActions, IntegrationFormButton } from "./_components/IntegrationForm";

export const metadata = { title: "Integrations · LekkerWerk" };

export default async function IntegrationsPage() {
  const ctx = await requirePageContext("integrations:manage");
  const company = await getCompany(ctx);
  const today = localDate(new Date(), company.timezone);
  const [items, summary] = await Promise.all([listIntegrations(ctx), importedHoursSummary(ctx, addDays(today, -30), today)]);
  const syncs = await Promise.all(items.map((i) => listSyncs(ctx, i.id, 5)));
  const fmt = (d: Date | null) => (d ? formatDateTime(d, company.timezone) : "—");

  return (
    <>
      <PageHeader
        title="Integrations"
        description="Connect ERP, accounting, payroll or HR systems. Data syncs in the background, so the dashboard never waits on an external API."
        actions={<IntegrationFormButton />}
      />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard label="Connected systems" value={items.filter((i) => i.enabled).length} />
        <StatCard label="Imported records (30 days)" value={summary.records} hint="Shown separately from clock data generated here" />
        <StatCard label="Imported hours (30 days)" value={summary.hours.toFixed(1)} hint="Compare in Reports → ERP reconciliation" />
      </div>

      {items.length === 0 ? (
        <Card><EmptyState title="No integrations connected" hint="Start with Custom API for any system with a REST endpoint, or Odoo." /></Card>
      ) : (
        <div className="flex flex-col gap-6">
          {items.map((i, idx) => (
            <Card
              key={i.id}
              title={`${i.name} · ${catalogByProvider[i.provider].label}`}
              action={<div className="flex items-center gap-2"><Badge tone={i.enabled ? "green" : "gray"}>{i.enabled ? "Enabled" : "Disabled"}</Badge><IntegrationFormButton integration={i} /></div>}
            >
              <dl className="grid gap-4 text-sm sm:grid-cols-4">
                <div><dt className="text-xs text-muted">Last successful sync</dt><dd>{fmt(i.lastSuccessfulSyncAt)}</dd></div>
                <div><dt className="text-xs text-muted">Last failed sync</dt><dd>{fmt(i.lastFailedSyncAt)}</dd></div>
                <div><dt className="text-xs text-muted">Next scheduled sync</dt><dd>{i.enabled ? fmt(i.nextSyncAt) : "—"}</dd></div>
                <div><dt className="text-xs text-muted">Frequency</dt><dd>every {i.syncFrequencyMinutes} min</dd></div>
              </dl>
              {i.lastError && <p className="mt-3 rounded-[10px] bg-red-50 px-3 py-2 text-sm text-red-700">Last error: {i.lastError}</p>}
              <div className="mt-4"><IntegrationActions id={i.id} /></div>

              {syncs[idx].length > 0 && (
                <div className="mt-5 -mx-5 border-t border-border">
                  <Table>
                    <thead><tr><Th>Started</Th><Th>Status</Th><Th>Duration</Th><Th>Records</Th><Th>Error</Th></tr></thead>
                    <tbody>
                      {syncs[idx].map((s) => (
                        <tr key={s.id}>
                          <Td>{fmt(s.startedAt ?? s.createdAt)}</Td>
                          <Td><Badge tone={statusTone(s.status)}>{s.status.toLowerCase()}</Badge></Td>
                          <Td>{s.durationMs != null ? `${(s.durationMs / 1000).toFixed(1)}s` : "—"}</Td>
                          <Td>{s.recordsImported}</Td>
                          <Td className="max-w-xs truncate text-red-600">{s.errorMessage ?? ""}</Td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
      <p className="mt-6 text-sm text-muted">
        Compare imported and system hours in <Link href="/reports" className="font-medium text-dark-green">Reports → ERP reconciliation</Link>.
      </p>
    </>
  );
}
