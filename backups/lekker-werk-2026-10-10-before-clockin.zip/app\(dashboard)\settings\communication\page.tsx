import { Card } from "@/components/dashboard/ui";
import { requirePageContext } from "@/server/auth/guards";
import { listChannels } from "@/server/services/company.service";
import { ChannelForm } from "../_components/ChannelForm";

export const metadata = { title: "Communication · LekkerWerk" };

export default async function CommunicationSettingsPage() {
  const ctx = await requirePageContext("settings:manage");
  const channels = await listChannels(ctx);
  const tg = channels.find((c) => c.channel === "TELEGRAM");
  const wa = channels.find((c) => c.channel === "WHATSAPP");

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {tg && (
        <Card title={`Telegram${tg.isDefault ? " · default" : ""}`}>
          <ChannelForm channel="TELEGRAM" state={tg} />
        </Card>
      )}
      {wa && (
        <Card title={`WhatsApp${wa.isDefault ? " · default" : ""}`}>
          <ChannelForm channel="WHATSAPP" state={wa} />
        </Card>
      )}
    </div>
  );
}
