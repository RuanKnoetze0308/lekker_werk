// UI-safe metadata (no secrets, no server imports). Drives the Integrations settings forms.

export interface FieldDef {
  key: string;
  label: string;
  placeholder?: string;
  secret?: boolean;
  required?: boolean;
}

export interface ProviderMeta {
  provider: "CUSTOM_API" | "SYSPRO" | "ODOO" | "SAGE" | "XERO" | "QUICKBOOKS";
  label: string;
  categories: ("ERP" | "ACCOUNTING" | "PAYROLL" | "HR")[];
  implemented: boolean;
  configFields: FieldDef[];
  credentialFields: FieldDef[];
}

export const PROVIDER_CATALOG: ProviderMeta[] = [
  {
    provider: "CUSTOM_API",
    label: "Custom API",
    categories: ["ERP", "ACCOUNTING", "PAYROLL", "HR"],
    implemented: true,
    configFields: [
      { key: "apiUrl", label: "API URL (https)", placeholder: "https://erp.example.com/api/hours", required: true },
      { key: "employeeKey", label: "Employee field name", placeholder: "employee_number" },
      { key: "dateKey", label: "Date field name", placeholder: "date" },
      { key: "hoursKey", label: "Hours field name", placeholder: "hours" },
      { key: "idKey", label: "Record id field name", placeholder: "id" },
    ],
    credentialFields: [{ key: "apiKey", label: "API key", secret: true, required: true }],
  },
  {
    provider: "ODOO",
    label: "Odoo",
    categories: ["ERP", "HR"],
    implemented: true,
    configFields: [
      { key: "apiUrl", label: "Odoo URL", placeholder: "https://mycompany.odoo.com", required: true },
      { key: "database", label: "Database", required: true },
      { key: "username", label: "Username", required: true },
    ],
    credentialFields: [{ key: "password", label: "Password / API key", secret: true, required: true }],
  },
  {
    provider: "SYSPRO",
    label: "Syspro",
    categories: ["ERP", "PAYROLL"],
    implemented: false,
    configFields: [
      { key: "apiUrl", label: "e.net / REST URL", required: true },
      { key: "company", label: "Company ID", required: true },
      { key: "username", label: "Operator", required: true },
    ],
    credentialFields: [{ key: "password", label: "Password", secret: true, required: true }],
  },
  {
    provider: "SAGE",
    label: "Sage",
    categories: ["ACCOUNTING", "PAYROLL"],
    implemented: false,
    configFields: [{ key: "tenant", label: "Tenant / business id", required: true }],
    credentialFields: [{ key: "apiKey", label: "API key", secret: true, required: true }],
  },
  {
    provider: "XERO",
    label: "Xero",
    categories: ["ACCOUNTING", "PAYROLL"],
    implemented: false,
    configFields: [{ key: "tenant", label: "Tenant id", required: true }],
    credentialFields: [
      { key: "clientId", label: "Client id", required: true },
      { key: "clientSecret", label: "Client secret", secret: true, required: true },
    ],
  },
  {
    provider: "QUICKBOOKS",
    label: "QuickBooks",
    categories: ["ACCOUNTING", "PAYROLL"],
    implemented: false,
    configFields: [{ key: "realmId", label: "Realm / company id", required: true }],
    credentialFields: [
      { key: "clientId", label: "Client id", required: true },
      { key: "clientSecret", label: "Client secret", secret: true, required: true },
    ],
  },
];

export const catalogByProvider = Object.fromEntries(PROVIDER_CATALOG.map((p) => [p.provider, p]));
