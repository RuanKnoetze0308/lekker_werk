import "server-only";
import { AppError } from "../../errors";
import type { ChannelSender, OutboundMessage } from "../types";

const api = (token: string, method: string) => `https://api.telegram.org/bot${token}/${method}`;

async function call<T>(token: string, method: string, body?: unknown): Promise<T> {
  const res = await fetch(api(token, method), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(10_000),
  });
  const json = (await res.json()) as { ok: boolean; result: T; description?: string };
  if (!json.ok) throw new AppError(502, "TELEGRAM_ERROR", json.description ?? "Telegram request failed");
  return json.result;
}

/** Validates the bot token and points Telegram at this company's webhook. */
export async function registerTelegramWebhook(token: string, url: string, secret: string) {
  const me = await call<{ username: string }>(token, "getMe");
  await call(token, "setWebhook", {
    url,
    secret_token: secret,
    allowed_updates: ["message", "callback_query"],
    drop_pending_updates: true,
  });
  return { username: me.username };
}

export function telegramSender(token: string): ChannelSender {
  return {
    async send(chatId: string, msg: OutboundMessage) {
      const reply_markup = msg.requestLocation
        ? {
            keyboard: [[{ text: "📍 Share my location", request_location: true }]],
            one_time_keyboard: true,
            resize_keyboard: true,
          }
        : msg.buttons?.length
          ? {
              inline_keyboard: chunk(
                msg.buttons.map((b) => ({ text: b.label, callback_data: b.id })),
                2,
              ),
            }
          : { remove_keyboard: true };
      await call(token, "sendMessage", { chat_id: chatId, text: msg.text, reply_markup });
    },
  };
}

export async function answerCallback(token: string, callbackId: string) {
  await call(token, "answerCallbackQuery", { callback_query_id: callbackId }).catch(() => {});
}

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}
