import "server-only";
import { and, count, desc, eq, gte, isNull, notExists, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { db, type Tx } from "@/db/client";
import {
  clockAttempts,
  clockEvents,
  communicationAccounts,
  employeeLocations,
  employees,
  locations,
} from "@/db/schema";
import { distanceMeters } from "@/lib/geo";
import { addDays, formatTime, localDate } from "@/lib/time";
import { getBillingAccess } from "../billing/billing.service";
import { getSettings } from "../services/company.service";
import { recomputeDay } from "../services/attendance.service";
import { notify } from "../services/notification.service";
import { rateLimit } from "../services/rate-limit.service";
import { resolveQrToken } from "../services/qr.service";
import { ACTION_VERB, REJECTION_MESSAGES } from "./messages";
import type {
  ClockAction,
  ClockRequest,
  ClockResult,
  ClockState,
  RejectionReasonCode,
} from "./types";

const superseding = alias(clockEvents, "superseding");

/** Current state from the ledger. Stale open shifts (forgot to clock out) read as OUT. */
export async function getClockState(
  employeeId: string,
  maxShiftHours: number,
  now = new Date(),
  executor: Pick<typeof db, "select"> = db,
): Promise<{ state: ClockState; last: { eventType: ClockAction; occurredAt: Date } | null }> {
  const [last] = await executor
    .select({ eventType: clockEvents.eventType, occurredAt: clockEvents.occurredAt })
    .from(clockEvents)
    .where(
      and(
        eq(clockEvents.employeeId, employeeId),
        eq(clockEvents.validationStatus, "ACCEPTED"),
        notExists(
          db.select({ x: sql`1` }).from(superseding).where(eq(superseding.correctsEventId, clockEvents.id)),
        ),
      ),
    )
    .orderBy(desc(clockEvents.occurredAt))
    .limit(1);

  if (!last || last.eventType === "CLOCK_OUT") return { state: "OUT", last: last ?? null };
  if (now.getTime() - last.occurredAt.getTime() > maxShiftHours * 3600_000) return { state: "OUT", last };
  return { state: last.eventType === "BREAK_START" ? "BREAK" : "IN", last };
}

interface Reject {
  companyId: string | null;
  employeeId: string | null;
  locationId: string | null;
  qrCodeId: string | null;
  req: ClockRequest;
  reason: RejectionReasonCode;
  extra?: Record<string, unknown>;
}

async function logRejection(r: Reject): Promise<ClockResult> {
  await db.insert(clockAttempts).values({
    companyId: r.companyId,
    employeeId: r.employeeId,
    locationId: r.locationId,
    qrCodeId: r.qrCodeId,
    requestedAction: r.req.action,
    source: r.req.source,
    status: "REJECTED",
    rejectionReason: r.reason,
    latitude: r.req.latitude,
    longitude: r.req.longitude,
    externalId: r.req.externalId,
    idempotencyKey: r.req.idempotencyKey,
    metadata: r.extra ?? {},
  });

  // Repeated failures from one employee in a short window are worth a manager's attention.
  if (r.employeeId && r.companyId && r.reason !== "RATE_LIMITED") {
    const [{ n }] = await db
      .select({ n: count() })
      .from(clockAttempts)
      .where(
        and(
          eq(clockAttempts.employeeId, r.employeeId),
          eq(clockAttempts.status, "REJECTED"),
          gte(clockAttempts.createdAt, new Date(Date.now() - 10 * 60_000)),
        ),
      );
    if (n === 5) {
      await notify({
        companyId: r.companyId,
        type: "UNUSUAL_CLOCKING",
        title: "Repeated failed clocking attempts",
        body: `An employee failed to clock ${n} times in 10 minutes (${r.reason}).`,
        payload: { employeeId: r.employeeId },
      });
    }
  }
  return { ok: false, reason: r.reason, message: REJECTION_MESSAGES[r.reason] };
}

export async function processClock(req: ClockRequest): Promise<ClockResult> {
  const now = req.now ?? new Date();
  const base = { companyId: req.companyId, employeeId: null, locationId: null, qrCodeId: null, req };

  if (!(await rateLimit(`clock:${req.companyId}:${req.externalId ?? req.employeeId}`, 20, 60))) {
    return logRejection({ ...base, reason: "RATE_LIMITED" });
  }

  // Clocking pauses (and says why) once the trial / subscription has lapsed.
  if ((await getBillingAccess(req.companyId)).locked) {
    return logRejection({ ...base, reason: "SUBSCRIPTION_INACTIVE" });
  }

  // ---- Employee ----------------------------------------------------------------------------
  let accountId: string | null = null;
  let employeeId = req.employeeId ?? null;

  if (!employeeId) {
    if (!req.channel || !req.externalId) return logRejection({ ...base, reason: "ACCOUNT_NOT_LINKED" });
    const [acct] = await db
      .select({ id: communicationAccounts.id, employeeId: communicationAccounts.employeeId })
      .from(communicationAccounts)
      .where(
        and(
          eq(communicationAccounts.companyId, req.companyId),
          eq(communicationAccounts.channel, req.channel),
          eq(communicationAccounts.externalId, req.externalId),
          isNull(communicationAccounts.revokedAt),
        ),
      );
    if (!acct) return logRejection({ ...base, reason: "ACCOUNT_NOT_LINKED" });
    accountId = acct.id;
    employeeId = acct.employeeId;
  }

  const [employee] = await db.select().from(employees).where(eq(employees.id, employeeId));
  if (!employee || employee.companyId !== req.companyId) {
    return logRejection({ ...base, reason: "WRONG_COMPANY" });
  }
  const withEmp = { ...base, employeeId: employee.id, locationId: employee.locationId };
  if (employee.status !== "ACTIVE") return logRejection({ ...withEmp, reason: "EMPLOYEE_INACTIVE" });

  const settings = (await getSettings(req.companyId)).attendance;

  // ---- QR / location -----------------------------------------------------------------------
  let locationId = employee.locationId;
  let qrCodeId: string | null = null;
  if (req.qrToken) {
    const qr = await resolveQrToken(req.qrToken);
    if (!qr || qr.companyId !== req.companyId) return logRejection({ ...withEmp, reason: "QR_INVALID" });
    const typeMismatch =
      (qr.type === "CLOCK_IN" && req.action !== "CLOCK_IN") ||
      (qr.type === "CLOCK_OUT" && req.action !== "CLOCK_OUT");
    if (typeMismatch) return logRejection({ ...withEmp, qrCodeId: qr.id, reason: "QR_INVALID" });
    if (!qr.enabled) return logRejection({ ...withEmp, qrCodeId: qr.id, reason: "QR_DISABLED" });
    if (qr.expiresAt && qr.expiresAt < now) return logRejection({ ...withEmp, qrCodeId: qr.id, reason: "QR_EXPIRED" });
    locationId = qr.locationId;
    qrCodeId = qr.id;
  } else if (req.source !== "WEB" && settings.requireQrForClocking) {
    return logRejection({ ...withEmp, reason: "QR_INVALID" });
  }
  const ctxRej = { ...withEmp, locationId, qrCodeId };

  const allowed = await db
    .select({ id: employeeLocations.locationId })
    .from(employeeLocations)
    .where(eq(employeeLocations.employeeId, employee.id));
  const allowedIds = new Set([employee.locationId, ...allowed.map((a) => a.id)]);
  const [location] = await db
    .select()
    .from(locations)
    .where(and(eq(locations.id, locationId), eq(locations.companyId, req.companyId)));
  if (!location || location.status !== "ACTIVE" || !allowedIds.has(locationId)) {
    return logRejection({ ...ctxRej, reason: "NOT_ALLOWED_AT_LOCATION" });
  }

  // ---- GPS ---------------------------------------------------------------------------------
  let distance: number | null = null;
  const gpsOn = location.gpsValidationEnabled ?? settings.gpsValidationEnabled;
  if (gpsOn && location.latitude != null && location.longitude != null) {
    if (req.latitude == null || req.longitude == null) {
      return logRejection({ ...ctxRej, reason: "GPS_REQUIRED" });
    }
    distance = distanceMeters(req.latitude, req.longitude, location.latitude, location.longitude);
    const radius = location.allowedRadiusMeters ?? settings.allowedRadiusMeters;
    if (distance > radius) {
      return logRejection({ ...ctxRej, reason: "OUTSIDE_RADIUS", extra: { distance: Math.round(distance) } });
    }
  }

  if ((req.action === "BREAK_START" || req.action === "BREAK_END") && !settings.breaksEnabled) {
    return logRejection({ ...ctxRej, reason: "CLOCKING_NOT_ALLOWED" });
  }

  // ---- Idempotency ---------------------------------------------------------------------------
  if (req.idempotencyKey) {
    const [seen] = await db
      .select({ id: clockAttempts.id })
      .from(clockAttempts)
      .where(and(eq(clockAttempts.idempotencyKey, req.idempotencyKey), eq(clockAttempts.status, "ACCEPTED")))
      .limit(1);
    if (seen) return logRejection({ ...ctxRej, reason: "DUPLICATE" });
  }

  // ---- State machine + write (serialised per employee) ---------------------------------------------
  type Outcome = { reject: RejectionReasonCode } | { event: NonNullable<ClockResult["event"]>; state: ClockState };

  const outcome: Outcome = await db.transaction(async (tx: Tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(hashtextextended(${employee.id}, 0))`);

    const { state, last } = await getClockState(employee.id, settings.maxShiftHours, now, tx);

    if (
      last &&
      last.eventType === req.action &&
      now.getTime() - last.occurredAt.getTime() < settings.duplicateWindowSeconds * 1000
    ) {
      return { reject: "DUPLICATE" as const };
    }

    const reject = transition(state, req.action);
    if (reject) return { reject };

    const [ev] = await tx
      .insert(clockEvents)
      .values({
        companyId: req.companyId,
        employeeId: employee.id,
        locationId,
        eventType: req.action,
        occurredAt: now, // always server time; client clocks are never trusted
        source: req.source,
        latitude: req.latitude,
        longitude: req.longitude,
        distanceMeters: distance,
        qrCodeId,
        communicationAccountId: accountId,
      })
      .returning({ id: clockEvents.id });

    await tx.insert(clockAttempts).values({
      companyId: req.companyId,
      employeeId: employee.id,
      locationId,
      qrCodeId,
      requestedAction: req.action,
      source: req.source,
      status: "ACCEPTED",
      clockEventId: ev.id,
      latitude: req.latitude,
      longitude: req.longitude,
      externalId: req.externalId,
      idempotencyKey: req.idempotencyKey,
    });

    const today = localDate(now, location.timezone);
    await recomputeDay(tx, employee.id, today, now);
    await recomputeDay(tx, employee.id, addDays(today, -1), now);

    const next: ClockState =
      req.action === "CLOCK_IN" || req.action === "BREAK_END" ? "IN" : req.action === "BREAK_START" ? "BREAK" : "OUT";
    return {
      event: { id: ev.id, eventType: req.action, occurredAt: now, locationName: location.name, timezone: location.timezone },
      state: next,
    };
  });

  if ("reject" in outcome) return logRejection({ ...ctxRej, reason: outcome.reject });

  return {
    ok: true,
    state: outcome.state,
    employee: { id: employee.id, firstName: employee.firstName },
    event: outcome.event,
    message: `You've ${ACTION_VERB[req.action]} at ${formatTime(outcome.event.occurredAt, outcome.event.timezone)} (${outcome.event.locationName}).`,
  };
}

function transition(state: ClockState, action: ClockAction): RejectionReasonCode | null {
  switch (action) {
    case "CLOCK_IN":
      return state === "OUT" ? null : "ALREADY_CLOCKED_IN";
    case "CLOCK_OUT":
      return state === "IN" ? null : state === "BREAK" ? "ALREADY_ON_BREAK" : "NOT_CLOCKED_IN";
    case "BREAK_START":
      return state === "IN" ? null : state === "BREAK" ? "ALREADY_ON_BREAK" : "NOT_CLOCKED_IN";
    case "BREAK_END":
      return state === "BREAK" ? null : "NOT_ON_BREAK";
  }
}
