import "server-only";
import { and, eq } from "drizzle-orm";
import { db } from "@/db/client";
import { communicationChannels } from "@/db/schema";
import { decryptJson, safeEqual } from "@/lib/crypto";
import { Errors } from "../../errors";
import { handleInbound } from "../messaging.service";
import type { InboundMessage } from "../types";
import { answerCallback, telegramSender } from "./client";

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    chat: { id: number };
    from?: { first_name?: string; username?: string };
    text?: string;
    location?: { latitude: number; longitude: number };
  };
  callback_query?: {
    id: string;
    data?: string;
    from: { first_name?: string };
    message?: { chat: { id: number } };
  };
}

/** `secret` comes from the webhook URL path; the header is Telegram's own secret_token echo. */
export async function handleTelegramWebhook(secret: string, headerSecret: string | null, update: TelegramUpdate) {
  const [channel] = await db
    .select()
    .from(communicationChannels)
    .where(and(eq(communicationChannels.webhookSecret, secret), eq(communicationChannels.channel, "TELEGRAM")));
  if (!channel || !channel.enabled || !channel.encryptedCredentials) throw Errors.notFound("Channel");
  if (!headerSecret || !safeEqual(headerSecret, channel.webhookSecret)) throw Errors.forbidden("Bad secret.");

  const { botToken } = decryptJson<{ botToken: string }>(channel.encryptedCredentials);
  const sender = telegramSender(botToken);

  let inbound: InboundMessage | null = null;
  if (update.message) {
    const m = update.message;
    inbound = {
      companyId: channel.companyId,
      channel: "TELEGRAM",
      externalId: String(m.chat.id),
      displayName: m.from?.first_name ?? m.from?.username,
      messageId: `${update.update_id}`,
      text: m.text,
      location: m.location,
    };
  } else if (update.callback_query?.message) {
    const cb = update.callback_query;
    inbound = {
      companyId: channel.companyId,
      channel: "TELEGRAM",
      externalId: String(cb.message!.chat.id),
      displayName: cb.from.first_name,
      messageId: `${update.update_id}`,
      text: cb.data,
    };
    await answerCallback(botToken, cb.id);
  }
  if (inbound) await handleInbound(inbound, sender, channel.publicHandle);
}
