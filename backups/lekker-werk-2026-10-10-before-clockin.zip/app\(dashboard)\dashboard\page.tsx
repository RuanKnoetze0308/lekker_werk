import Link from "next/link";
import {
  Card,
  FilterBar,
  FilterField,
  PageHeader,
  StatCard,
  Table,
  Td,
  Th,
  filterControl,
} from "@/components/dashboard/ui";
import { formatMinutes } from "@/lib/time";
import { readParams, type SearchParams } from "@/lib/page-utils";
import { requirePageContext } from "@/server/auth/guards";
import { getDashboardOverview } from "@/server/services/dashboard.service";
import { listDepartments } from "@/server/services/employee.service";
import { listLocations } from "@/server/services/location.service";
import { listManagerUsers } from "@/server/services/user.service";

export const metadata = { title: "Dashboard · LekkerWerk" };

export default async function DashboardPage({ searchParams }: { searchParams: SearchParams }) {
  const ctx = await requirePageContext("dashboard:view");
  const p = await readParams(searchParams);
  const filters = {
    date: p.get("date"),
    locationId: p.get("locationId"),
    department: p.get("department"),
    managerId: p.get("managerId"),
  };

  const [data, locations, departments, managers] = await Promise.all([
    getDashboardOverview(ctx, filters),
    listLocations(ctx),
    listDepartments(ctx),
    ctx.role === "COMPANY_ADMIN" || ctx.role === "SUPER_ADMIN" ? listManagerUsers(ctx) : Promise.resolve([]),
  ]);
  const t = data.today;
  const w = data.workforce;

  return (
    <>
      <PageHeader
        title="Dashboard"
        description={`${data.isToday ? "Today" : data.date} · times shown in ${data.timezone}`}
      />

      <FilterBar action="/dashboard">
        <FilterField label="Date">
          <input type="date" name="date" defaultValue={data.date} className={filterControl} />
        </FilterField>
        <FilterField label="Location">
          <select name="locationId" defaultValue={filters.locationId ?? ""} className={filterControl}>
            <option value="">All locations</option>
            {locations.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </FilterField>
        <FilterField label="Department">
          <select name="department" defaultValue={filters.department ?? ""} className={filterControl}>
            <option value="">All departments</option>
            {departments.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </FilterField>
        {managers.length > 0 && (
          <FilterField label="Manager">
            <select name="managerId" defaultValue={filters.managerId ?? ""} className={filterControl}>
              <option value="">All managers</option>
              {managers.map((m) => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </select>
          </FilterField>
        )}
      </FilterBar>

      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted">Today&rsquo;s overview</h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Clocked in" value={t.clockedIn} tone="good" hint={t.onBreak ? `${t.onBreak} on break` : undefined} />
        <StatCard label="Clocked out" value={t.clockedOut} />
        <StatCard label="Hours worked" value={formatMinutes(t.workedMinutes)} hint={`of ${formatMinutes(t.scheduledMinutes)} scheduled`} />
        <StatCard label="Overtime" value={formatMinutes(t.overtimeMinutes)} tone={t.overtimeMinutes ? "warn" : "default"} />
        <StatCard label="Late arrivals" value={t.lateArrivals} tone={t.lateArrivals ? "warn" : "default"} />
        <StatCard label="Early departures" value={t.earlyDepartures} tone={t.earlyDepartures ? "warn" : "default"} />
        <StatCard label="Absent" value={t.absent} tone={t.absent ? "bad" : "default"} />
        <StatCard
          label="Pending issues"
          value={t.incompleteRecords + t.rejectedAttempts}
          tone={t.incompleteRecords + t.rejectedAttempts ? "bad" : "default"}
          hint={`${t.incompleteRecords} incomplete · ${t.rejectedAttempts} rejected (24h)`}
        />
      </div>

      <h2 className="mb-3 mt-8 text-sm font-semibold uppercase tracking-wide text-muted">Workforce summary (month to date)</h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total employees" value={w.totalEmployees} />
        <StatCard label="Hours worked" value={formatMinutes(w.monthWorkedMinutes)} hint={`${formatMinutes(w.monthScheduledMinutes)} scheduled`} />
        <StatCard label="Overtime" value={formatMinutes(w.monthOvertimeMinutes)} />
        <StatCard label="Attendance" value={w.attendanceRate === null ? "—" : `${w.attendanceRate}%`} hint="Days worked ÷ days expected" />
      </div>

      <Card title="Employees per location" className="mt-8" flush>
        {w.perLocation.length === 0 ? (
          <p className="p-5 text-sm text-muted">No locations yet.</p>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Location</Th>
                <Th className="text-right">Employees</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {w.perLocation.map((l) => (
                <tr key={l.locationId}>
                  <Td className="font-medium">{l.name}</Td>
                  <Td className="text-right">{l.employees}</Td>
                  <Td className="text-right">
                    <Link href={`/locations/${l.locationId}?date=${data.date}`} className="font-medium text-dark-green hover:underline">
                      View day →
                    </Link>
                  </Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
