"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { Field, FormMessage, Input, Toggle } from "@/components/ui/form";
import { Badge } from "@/components/dashboard/ui";
import { api, ApiError } from "@/lib/api-client";

interface State {
  enabled: boolean;
  configured: boolean;
  publicHandle: string | null;
  phoneNumberId: string | null;
  webhookUrl: string;
}

export function ChannelForm({ channel, state }: { channel: "TELEGRAM" | "WHATSAPP"; state: State }) {
  const router = useRouter();
  const [enabled, setEnabled] = useState(state.enabled);
  const [secret, setSecret] = useState("");
  const [phoneId, setPhoneId] = useState(state.phoneNumberId ?? "");
  const [display, setDisplay] = useState(state.publicHandle ?? "");
  const [pending, setPending] = useState(false);
  const [msg, setMsg] = useState<{ error?: string; success?: string }>({});

  async function save() {
    setPending(true);
    setMsg({});
    try {
      const body =
        channel === "TELEGRAM"
          ? { channel, enabled, botToken: secret || undefined }
          : { channel, enabled, phoneNumberId: phoneId || undefined, displayNumber: display || undefined, accessToken: secret || undefined };
      await api("/api/settings/channels", { method: "PUT", body });
      setSecret("");
      setMsg({ success: channel === "TELEGRAM" && secret ? "Bot connected and webhook registered." : "Saved." });
      router.refresh();
    } catch (err) {
      setMsg({ error: err instanceof ApiError ? err.message : "Could not save." });
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Enabled</span>
        <div className="flex items-center gap-3">
          <Badge tone={state.configured ? "green" : "amber"}>{state.configured ? "credentials saved" : "not configured"}</Badge>
          <Toggle checked={enabled} onChange={setEnabled} label={`${channel} enabled`} />
        </div>
      </div>

      {channel === "TELEGRAM" ? (
        <>
          <p className="text-sm text-muted">
            Create a bot with <b>@BotFather</b> on Telegram, then paste its token. We validate it and register the webhook automatically.
            {state.publicHandle && <> Connected bot: <b>@{state.publicHandle.replace(/^@/, "")}</b>.</>}
          </p>
          <Field label="Bot token" hint="Stored encrypted. Never shown again.">
            <Input type="password" autoComplete="off" value={secret} onChange={(e) => setSecret(e.target.value)} placeholder={state.configured ? "••••••••" : "123456:ABC-DEF…"} />
          </Field>
        </>
      ) : (
        <>
          <p className="text-sm text-muted">
            Uses the WhatsApp Business Cloud API. In Meta&rsquo;s developer console, point the webhook to the URL below and subscribe to <b>messages</b>.
          </p>
          <Field label="Phone number ID"><Input value={phoneId} onChange={(e) => setPhoneId(e.target.value)} /></Field>
          <Field label="Display number" hint="International format, used for QR click-to-chat links"><Input value={display} onChange={(e) => setDisplay(e.target.value)} placeholder="27821234567" /></Field>
          <Field label="Access token" hint="Stored encrypted. Never shown again.">
            <Input type="password" autoComplete="off" value={secret} onChange={(e) => setSecret(e.target.value)} placeholder={state.configured ? "••••••••" : ""} />
          </Field>
          <Field label="Webhook URL"><Input readOnly value={state.webhookUrl} onFocus={(e) => e.currentTarget.select()} /></Field>
        </>
      )}
      <FormMessage error={msg.error} success={msg.success} />
      <Button onClick={save} disabled={pending} className="w-fit">{pending ? "Saving…" : "Save"}</Button>
    </div>
  );
}
