import "server-only";
import { createHmac } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db/client";
import { communicationChannels } from "@/db/schema";
import { decryptJson, safeEqual } from "@/lib/crypto";
import { env } from "@/lib/env";
import { Errors } from "../../errors";
import { handleInbound } from "../messaging.service";
import { whatsappSender } from "./client";

interface WhatsAppPayload {
  entry?: {
    changes?: {
      value?: {
        metadata?: { phone_number_id?: string };
        contacts?: { wa_id: string; profile?: { name?: string } }[];
        messages?: {
          id: string;
          from: string;
          type: string;
          text?: { body: string };
          interactive?: { button_reply?: { id: string }; list_reply?: { id: string } };
          location?: { latitude: number; longitude: number };
        }[];
      };
    }[];
  }[];
}

/** Meta signs the raw body with the app secret. Reject anything that doesn't verify. */
export function verifyWhatsAppSignature(rawBody: string, header: string | null): boolean {
  const secret = env.whatsappAppSecret;
  if (!secret || !header?.startsWith("sha256=")) return false;
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  return safeEqual(header.slice(7), expected);
}

export async function handleWhatsAppWebhook(payload: WhatsAppPayload) {
  for (const entry of payload.entry ?? []) {
    for (const change of entry.changes ?? []) {
      const value = change.value;
      const phoneNumberId = value?.metadata?.phone_number_id;
      if (!value?.messages?.length || !phoneNumberId) continue;

      // Tenant is derived from the business phone number that received the message.
      const [channel] = await db
        .select()
        .from(communicationChannels)
        .where(
          and(
            eq(communicationChannels.channel, "WHATSAPP"),
            eq(communicationChannels.enabled, true),
            sql`${communicationChannels.config}->>'phoneNumberId' = ${phoneNumberId}`,
          ),
        );
      if (!channel?.encryptedCredentials) continue;
      const { accessToken } = decryptJson<{ accessToken: string }>(channel.encryptedCredentials);
      const sender = whatsappSender(phoneNumberId, accessToken);

      for (const m of value.messages) {
        const name = value.contacts?.find((c) => c.wa_id === m.from)?.profile?.name;
        await handleInbound(
          {
            companyId: channel.companyId,
            channel: "WHATSAPP",
            externalId: m.from,
            displayName: name,
            messageId: m.id,
            text:
              m.type === "text"
                ? m.text?.body
                : (m.interactive?.button_reply?.id ?? m.interactive?.list_reply?.id),
            location: m.type === "location" ? m.location : undefined,
          },
          sender,
          channel.publicHandle,
        );
      }
    }
  }
}

export function checkVerifyChallenge(mode: string | null, token: string | null) {
  if (mode !== "subscribe" || !token || !env.whatsappVerifyToken || !safeEqual(token, env.whatsappVerifyToken)) {
    throw Errors.forbidden("Verification failed.");
  }
}
