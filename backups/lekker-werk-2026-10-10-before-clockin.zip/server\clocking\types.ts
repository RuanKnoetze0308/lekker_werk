export type ClockAction = "CLOCK_IN" | "CLOCK_OUT" | "BREAK_START" | "BREAK_END";
export type ClockSourceType = "TELEGRAM" | "WHATSAPP" | "WEB";
export type ClockState = "OUT" | "IN" | "BREAK";

export type RejectionReasonCode =
  | "EMPLOYEE_INACTIVE"
  | "ACCOUNT_NOT_LINKED"
  | "WRONG_COMPANY"
  | "QR_INVALID"
  | "QR_DISABLED"
  | "QR_EXPIRED"
  | "NOT_ALLOWED_AT_LOCATION"
  | "GPS_REQUIRED"
  | "OUTSIDE_RADIUS"
  | "ALREADY_CLOCKED_IN"
  | "NOT_CLOCKED_IN"
  | "ALREADY_ON_BREAK"
  | "NOT_ON_BREAK"
  | "DUPLICATE"
  | "CLOCKING_NOT_ALLOWED"
  | "RATE_LIMITED"
  | "SUBSCRIPTION_INACTIVE";

/**
 * The only way anything (Telegram, WhatsApp, web) records attendance.
 * companyId must be derived server-side (webhook secret / session), never from user input.
 */
export interface ClockRequest {
  companyId: string;
  action: ClockAction;
  source: ClockSourceType;
  channel?: "TELEGRAM" | "WHATSAPP";
  externalId?: string;
  /** Pre-authorised employee (web/admin use). Chat sources resolve via externalId instead. */
  employeeId?: string;
  qrToken?: string;
  latitude?: number;
  longitude?: number;
  idempotencyKey?: string;
  now?: Date;
}

export interface ClockResult {
  ok: boolean;
  reason?: RejectionReasonCode;
  message: string;
  state?: ClockState;
  employee?: { id: string; firstName: string };
  event?: { id: string; eventType: ClockAction; occurredAt: Date; locationName: string; timezone: string };
}
